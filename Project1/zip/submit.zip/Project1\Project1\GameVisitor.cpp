/**
 * \file GameVisitor.cpp
 *
 * \author Hector
 */

#include "stdafx.h"
#include "GameVisitor.h"


CGameVisitor::CGameVisitor()
{
}


CGameVisitor::~CGameVisitor()
{
}
